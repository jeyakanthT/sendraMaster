<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EmployeeController extends CI_Controller {

	
	public function index()
	{
		$this->load->view('employees_create');
	}
	public function InsertEmployee()
	{
         //getting post values 
		$_POST = json_decode(file_get_contents('php://input'), true);
		 
		 $data = array(
				'ename'=>  $_POST['employee_name'],
				'email'=> $_POST['email'],
				'phone'=>  $_POST['phone'],
				'address'=>  $_POST['address']
				);
		//print_r($data);
		
	 	$this->load->model('EmployeeModel');
	     $this->EmployeeModel->employee_insert($data);
		 
		// echo "Inserted";
	 
	}
	
	
	public function ShowEmployees()
	{
          
	 	$this->load->model('EmployeeModel');
		$result =  $this->EmployeeModel->show_employees();
		echo "<table border='1' width='400px' cellspacing='4' cellpadding='4'><tr style='background:red;color:white;'><th>Emp.ID</th><th>Emp.Name</th><th>Email</th><th>Phone</th><th>Address</th></tr>";
	    foreach($result as $row)
		{
			echo "<tr>";
			echo "<td>". $row->empId . "</td>";
			echo "<td>". $row->ename . "</td>";
			echo "<td>". $row->email . "</td>";
			echo "<td>". $row->phone . "</td>";
			echo "<td>". $row->address . "</td>";
			echo "</tr>";
 
		}
		echo "</table>";
		 
		 
	 
	}
 
}