<?php
class EmployeeModel extends CI_Model
{
	 
	public function show_employees()
	{
  	    $query = $this->db->get('employees');
      	return $query->result();
		 
	}
	
	public function employee_insert($data)
	{
  		$this->db->insert('employees', $data);
	}
 
}

?>