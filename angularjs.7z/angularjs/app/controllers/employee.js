var app = angular.module("myapp",[]);
app.controller("employeecontroller",function($scope,$http){
 
	//update function 
	
		$scope.updatedata = function() {
		$http.post("<?php echo base_url(); ?>EmployeeController/ShowEmployees/")
		.success(function(data,status,headers,config){
 
           $scope.message = data;
			
		});
		
	}
 

});