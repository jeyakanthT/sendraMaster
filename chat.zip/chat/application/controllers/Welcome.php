<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	 function __construct() {
        parent::__construct();
        $this->load->model('login_model','login');
        $this->load->model('ajax_model','ajax');
    }	

	public function index()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','username','required');
		$this->form_validation->set_rules('password','password','required|trim|callback_accessValidation');
		
		if($this->form_validation->run()==FALSE){
			
			$this->load->view('login');
			
		}else
		{
			
			redirect('welcome/dashboard');
			
		}
	}

	public function accessValidation()
	{
			$username=$this->input->post('username');
			$password=MD5($this->input->post('password'));
			$status = $this->login->login_access($username,$password);
			
			if ($status->num_rows()>0) 
				{
					
					$row=$status->row();
					
					$data=array('userId'=>$row->userId,'employeeName'=>$row->employeeName,'employeeId'=>$row->employeeId,'departmentId'=>$row->departmentId,'designationId'=>$row->designationId);
					$this->session->set_userdata($data);
					
					return TRUE;
				}
				else {
					
					$this->form_validation->set_message('Invalid Username/password entered ');
					return FALSE;
				}
	}
	
	public function dashboard()
	{
		if($this->session->userdata('userId')!="")
		{
			$data['profile']=$this->ajax->userProfile($this->session->userdata('employeeId'));			
			$data['getAll']=$this->ajax->getAll($this->session->userdata('employeeId'));			
			$data['getGroups']=$this->ajax->getGroups($this->session->userdata('employeeId'));			
			$this->load->view('header',$data);
			$this->load->view('dashboard');
			$this->load->view('footer');
			
		}
		else
			$this->load->view('login1');
	}
	
	
}
