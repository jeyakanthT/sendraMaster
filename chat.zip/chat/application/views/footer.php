   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
   <script src="<?=base_url('assets/js/bootstrap.min.js') ?>"></script>
   <script src="<?=base_url('assets/js/customize.js') ?>"></script>
</body>
</html>