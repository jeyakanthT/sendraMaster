<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax_model extends CI_Model{
	
	public function __construct (){
      parent::__construct ();

   }
	
	function userProfile($employeeId)
	{		
		$this->db->select('*');
		$this->db->where('id',$employeeId);
		$sql = $this->db->get('employee')->row();
		return $sql;		
	}
	function getAll($employeeId)
	{		
		
		$this->db->select('e.id as employeeId,e.photo as photo,e.name as employeeName,e.mobile_number as mobileNumber,dp.description as departmentName,dg.description as designationName');
		$this->db->from('employee as e');
		$this->db->join('department as dp','e.department_id=dp.id','left');
		$this->db->join('designation as dg','e.designation_id=dg.id','left');		
		$this->db->where('e.id !=',$employeeId);
		$sql = $this->db->get();
		return $sql;		
	}
	
	function getGroups($employeeId)
	{		
		$this->db->select('gh.description as groupName,e.*,ey.name as createName');
		$this->db->from('group_details as gd');
		$this->db->join('group_header as gh','gd.group_header_id=gh.id','left');
		$this->db->join('employee as ey','gh.created_by=ey.id','left');
		$this->db->join('employee as e','gd.from_id=e.id or gd.to_id=e.id','left');
		$this->db->where('gd.from_id',$employeeId);
		$this->db->or_where('gd.to_id',$employeeId);
		$this->db->group_by('gd.group_header_id');
		$sql = $this->db->get();
		return $sql;		
	}
	
	
	
	
	
	
	
	
	
}