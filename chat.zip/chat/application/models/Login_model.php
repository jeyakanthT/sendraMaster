<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model{
	
	public function __construct (){
      parent::__construct ();

   }
	
	function login_access($username,$password)
	{
		
		$this->db->select('um.id as userId,e.name as employeeName,e.id as employeeId,e.department_id as departmentId,e.designation_id as designationId');
		$this->db->from('user_master as um');
		$this->db->join('employee as e','um.employee_id=e.id');
		$this->db->where('username',$username);
		$this->db->where('password',$password);
		$sql = $this->db->get();
		
		return $sql;
		
	}
	
	
	
	
	
	
	
	
	
}